# Oracle SQLDeveloper Puppet Module for Boxen

Install [Oracle SQLDeveloper](http://www.oracle.com/technetwork/developer-tools/sql-developer/overview/index.html)

## Usage

```puppet
include oracle_sqldeveloper
```

## Required Puppet Modules

* `boxen`

## Development

Write code. Run `script/cibuild` to test it. Check the `script`
directory for other useful tools.
