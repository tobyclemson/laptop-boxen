# Scons Puppet Module for Boxen

## Usage

```puppet
include scons
```

## Required Puppet Modules

* `boxen`
* `homebrew`
* `stdlib`
