# dpkg Puppet Module for Boxen

## Usage

```puppet
include dpkg
```

## Required Puppet Modules

* boxen
* homebrew
* stdlib
