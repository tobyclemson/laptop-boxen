# gpgtools Puppet Module for Boxen

Install [gpgtools](https://www.gpgtools.org/index.html) App to work with GPG

## Usage

```puppet
include gpgtools
```

## Required Puppet Modules

* boxen
